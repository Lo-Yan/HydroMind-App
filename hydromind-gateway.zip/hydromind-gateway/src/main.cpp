#include <Arduino.h>

/*
TODO
CHANGE TO AWS
SEND DATA TO AWS ONLY IF GOT VALUE (IE WHEN FINISH SHOWER)
*/


//  CREDITS:
// This code is modified based on the code by:
// - Jonas Byström @ https://github.com/jonasbystrom/ESP-Now-Sensor-system-with-WiFi/blob/main/espnow_sensor/espnow_sensor.ino


// ------------------------------------------------------------------------------------------
// CONFIG VARIABLES THAT NEED TO BE EDITED
// ------------------------------------------------------------------------------------------
// ESP-NOW SYSTEM CONFIGS - Gateway_Mac
// ESP-NOW GATEWAY CONFIGS - SOFTAP_SSID, SOFTAP_PASS, UNITS
// SETUP FOR AWS - BLYNK_AUTH_TOKEN

// ------------------------------------------------------------------------------------------
// ESP-NOW SYSTEM CONFIGS
// ------------------------------------------------------------------------------------------
#include <esp_now.h>
#include <esp_wifi.h>
#include <WiFi.h>
#include <WiFiMulti.h>
// This is the MAC address to be installed (sensors shall then send to this MAC address)
uint8_t GatewayMac[] = {0x58, 0xCF, 0x79, 0xE4, 0x4E, 0x60};

// ESP-Now message format. Sensor data is transmitted using this struct.
typedef struct sensor_data_t
{           // Sensor data format for sending on ESP-Now to Gateway
  int unit; // Unit no to identy which sensor is sending
  int totalMilliLitres;
  unsigned long updated; // Epoch time when received by Gateway. Set by gateway/receiver. (Not used by sensor, but part of struct for convenience reasons.)
} sensor_data_t;

// ------------------------------------------------------------------------------------------
// ESP-NOW GATEWAY CONFIGS
// ------------------------------------------------------------------------------------------
// Router WiFi Credentials (runnning on 2.4GHz and Channel=1)
// ****if using hotspot (go to settings) -> configure -> advanced -> broadcast channel -> 1 **** //
#define SOFTAP_SSID "joanneeqin"
#define SOFTAP_PASS "joanneeqin01"

#define UNITS 1 // No of esp-now sensor units supported to receive from. ESP-Now has a maximum of 20

// ------------------------------------------------------------------------------------------
// GLOBALS
// ------------------------------------------------------------------------------------------
WiFiMulti wifiMulti;
sensor_data_t bufSensorData;         // buffer for incoming data
sensor_data_t sensorData[UNITS + 1]; // buffer for all sensor data

// ------------------------------------------------------------------------------------------
// ESP-NOW functions
// ------------------------------------------------------------------------------------------
void OnDataRecv(const uint8_t *mac_addr, const uint8_t *data, int data_len)
{
  char macStr[24];
  snprintf(macStr, sizeof(macStr), " %02x:%02x:%02x:%02x:%02x:%02x",
           mac_addr[0], mac_addr[1], mac_addr[2], mac_addr[3], mac_addr[4], mac_addr[5]);
  Serial.print("\nData received from: ");
  Serial.println(macStr);
  memcpy(&bufSensorData, data, sizeof(bufSensorData));

  // Print data
  Serial.println("");
  Serial.print("Unit: ");
  Serial.print(bufSensorData.unit);
  Serial.print("   totalMilliLitres: ");
  Serial.print(bufSensorData.totalMilliLitres);
  Serial.println("");

  // Store data
  int i = bufSensorData.unit;
  if ((i >= 1) && (i <= UNITS))
  {
    memcpy(&sensorData[i], data, sizeof(bufSensorData));
  };
}

// ------------------------------------------------------------------------------------------
// SETUP FOR AWS
// ------------------------------------------------------------------------------------------
#include "secrets.h"
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#define AWS_IOT_PUBLISH_TOPIC   "esp32/pub"
#define AWS_IOT_SUBSCRIBE_TOPIC "esp32/sub"
void messageHandler(char* topic, byte* payload, unsigned int length);
WiFiClientSecure net = WiFiClientSecure();
PubSubClient client(net);

// ------------------------------------------------------------------------------------------
// AWS functions
// ------------------------------------------------------------------------------------------
void connectAWS()
{
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
 
  Serial.println("Connecting to Wi-Fi");
 
  while (WiFi.waitForConnectResult() != WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");
  }
  
  // Configure WiFiClientSecure to use the AWS IoT device credentials
  net.setCACert(AWS_CERT_CA);
  net.setCertificate(AWS_CERT_CRT);
  net.setPrivateKey(AWS_CERT_PRIVATE);
 
  // Connect to the MQTT broker on the AWS endpoint we defined earlier
  client.setServer(AWS_IOT_ENDPOINT, 8883);
 
  // Create a message handler
  client.setCallback(messageHandler);
 
  Serial.println("Connecting to AWS IOT");
 
  while (!client.connect(THINGNAME))
  {
    Serial.print(".");
    delay(100);
  }
 
  if (!client.connected())
  {
    Serial.println("AWS IoT Timeout!");
    return;
  }
 
  // Subscribe to a topic
  client.subscribe(AWS_IOT_SUBSCRIBE_TOPIC);
 
  Serial.println("AWS IoT Connected!");
}

void publishMessage(int totalMilliLitres)
{
  StaticJsonDocument<200> doc;
  doc["totalMilliLitres"] = totalMilliLitres;
  char jsonBuffer[512];
  serializeJson(doc, jsonBuffer); // print to client
 
  client.publish(AWS_IOT_PUBLISH_TOPIC, jsonBuffer);
}
 
void messageHandler(char* topic, byte* payload, unsigned int length)
{
  Serial.print("incoming: ");
  Serial.println(topic);
 
  StaticJsonDocument<200> doc;
  deserializeJson(doc, payload);
  const char* message = doc["message"];
  Serial.println(message);
}


// ------------------------------------------------------------------------------------
void setup()
// ------------------------------------------------------------------------------------
{ // Init Serial
  Serial.begin(115200);

  // Connect to WiFi ------------------------------
  Serial.print("Connecting to WiFi ");

  // Set device in AP mode to begin with
  WiFi.mode(WIFI_AP_STA); // AP _and_ STA is required (!IMPORTANT)

  wifiMulti.addAP(SOFTAP_SSID, SOFTAP_PASS); // I use wifiMulti ... just by habit, i guess ....
  while (wifiMulti.run() != WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");
  }

  // Come here - we are connected
  Serial.println(" Done");

  // Print WiFi data
  Serial.println("Set as AP_STA station.");
  Serial.print("SSID: ");
  Serial.println(WiFi.SSID());
  Serial.print("Channel: ");
  Serial.println(WiFi.channel());
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
  delay(1000);

  // Initialize ESP-Now ---------------------------

  // Config gateway AP - set SSID and channel
  int channel = WiFi.channel();
  if (WiFi.softAP(SOFTAP_SSID, SOFTAP_PASS, channel, 1))
  {
    Serial.println("AP Config Success. AP SSID: " + String(SOFTAP_SSID));
  }
  else
  {
    Serial.println("AP Config failed.");
  }

  // Print MAC addresses
  Serial.print("AP MAC: ");
  Serial.println(WiFi.softAPmacAddress());
  Serial.print("STA MAC: ");
  Serial.println(WiFi.macAddress());

// Init ESP-Now
#define ESPNOW_SUCCESS ESP_OK
+++++++++

  if (esp_now_init() == ESPNOW_SUCCESS)
  {
    Serial.println("ESP - Now Init Success");
  }
  else
  {
    Serial.println("ESP - Now Init Failed");
    ESP.restart(); // just restart if we cant init ESP-Now
  }

  // ESP-Now is now initialized. Register a callback fcn for when data is received
  esp_now_register_recv_cb(OnDataRecv);

  // Connect AWS IOT Core
  connectAWS();
}

// ------------------------------------------------------------------------------------
void loop()
// ------------------------------------------------------------------------------------
{
  double totalMilliLitres = bufSensorData.totalMilliLitres;
  publishMessage(totalMilliLitres);
  client.loop();
  delay(5000);
}